let students = [];

function addStudent() {

    let name = document.getElementById("name").value;
    let usn = document.getElementById("usn").value;
    let dept = document.getElementById("dept").value;
    let year = document.getElementById("year").value;
    let room = document.getElementById("room").value;

    if (name === "" || usn === "") {
        alert("Name and USN required");
        return;
    }

    let student = {
        name: name,
        usn: usn,
        dept: dept,
        year: year,
        room: room
    };

    console.log("Student Added:", student);

    // ✅ FIXED: correct PHP file name
    fetch("add_students.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(student)
    })
    .then(function(response) {
        return response.text();   // 👈 safer for debugging
    })
    .then(function(data) {
        console.log("RAW RESPONSE:", data);   // 👈 see actual error if any

        try {
            let json = JSON.parse(data);

            console.log("SERVER RESPONSE:", json);

            if (json.success) {
                alert("Student stored in DB ✅");
            } else {
                alert(json.message);
            }

        } catch (e) {
            console.error("JSON Parse Error:", e);
            alert("Server returned invalid JSON. Check console.");
        }
    })
    .catch(function(error) {
        console.error("Fetch Error:", error);
    });

    // clear inputs
    document.getElementById("name").value = "";
    document.getElementById("usn").value = "";
    document.getElementById("dept").value = "";
    document.getElementById("year").value = "";
    document.getElementById("room").value = "";
}




function deleteStudent() {

    let delName = document.getElementById("delName").value;
    let delUsn = document.getElementById("delUsn").value;

    if (delName === "" || delUsn === "") {
        alert("Enter Name and USN to delete");
        return;
    }

    fetch("delete_student.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: delName,
            usn: delUsn
        })
    })
    .then(function(response) {
        return response.text();   // 👈 same fix here
    })
    .then(function(data) {
        console.log("DELETE RAW RESPONSE:", data);

        try {
            let json = JSON.parse(data);

            console.log("DELETE RESPONSE:", json);

            if (json.success) {
                alert("Student deleted successfully ✅");

                let index = students.findIndex(function(s) {
                    return s.name === delName && s.usn === delUsn;
                });

                if (index !== -1) {
                    students.splice(index, 1);
                }

            } else {
                alert(json.message);
            }

        } catch (e) {
            console.error("Delete JSON Parse Error:", e);
            alert("Server returned invalid JSON.");
        }
    })
    .catch(function(error) {
        console.error("Delete Fetch Error:", error);
    });

    // clear inputs
    document.getElementById("delName").value = "";
    document.getElementById("delUsn").value = "";
}