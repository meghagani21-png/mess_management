<?php
include "db.php";

$sql = "UPDATE mess_db
SET total_days = DAY(LAST_DAY(CURDATE())) - IFNULL(reduced_no_of_days, 0)";

if ($conn->query($sql) === TRUE) {
    echo "Updated successfully<br>";

    $res = $conn->query("SELECT student_usn, total_days FROM mess_db");
    
    while($row = $res->fetch_assoc()) {
        echo $row['student_usn'] . " => " . $row['total_days'] . "<br>";
    }

} else {
    echo "Error: " . $conn->error;
}
?>