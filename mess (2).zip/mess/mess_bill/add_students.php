<?php
// ✅ Proper error handling
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");
include "db.php";

// ✅ Read input (supports browser + CLI)
$raw = file_get_contents("php://input");

if (empty($raw)) {
    // fallback for CLI
    $raw = file_get_contents("php://stdin");
}

$data = json_decode($raw, true);

// ✅ Validate JSON
if (!$data) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid JSON received",
        "raw" => $raw
    ]);
    exit;
}

// ✅ Validate required fields
if (empty($data['name']) || empty($data['usn'])) {
    echo json_encode([
        "success" => false,
        "message" => "Name and USN are required"
    ]);
    exit;
}

// ✅ Clean inputs
$name = trim($data['name']);
$usn  = trim($data['usn']);
$dept = $data['dept'] ?? '';
$year = $data['year'] ?? '';

// ✅ Check duplicate USN
$check = $conn->prepare("SELECT 1 FROM mess_db WHERE student_usn = ?");
$check->bind_param("s", $usn);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "USN already exists ❌"
    ]);
    exit;
}
$check->close();

// ✅ Get next Sl_no
$slResult = $conn->query("SELECT COALESCE(MAX(Sl_no), 0) + 1 AS next_sl FROM mess_db");
$row = $slResult->fetch_assoc();
$slNo = (int)$row['next_sl'];

// ✅ Insert student
$stmt = $conn->prepare(
    "INSERT INTO mess_db
    (Sl_no, Student_Name, student_usn, Student_Year, Student_Dept,
     Opening_balance, Total_mess_Rate, Total_mess_Rate_Service,
     total_mess_bill, closing_mess_amount)
     VALUES (?, ?, ?, ?, ?, 45000.00, 112.00, 117, 3677, 45000)"
);

$stmt->bind_param("issss", $slNo, $name, $usn, $year, $dept);
$stmt->execute();

// ✅ Success response
echo json_encode([
    "success" => true,
    "message" => "Student added successfully"
]);

$stmt->close();
$conn->close();
?>